# -*- coding: utf-8 -*-

from . import education_class,education_student,education_class2,education_student_ethnic,academy_enrollment
